#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
send request 'GET' to www.baidu.com
and save the receved content to a txt file
'''

from socket import *
import sys


def send(HOST, PORT, BUFSIZ, header_send):
    # create a socket which support IPv4/IPv6
    for res in getaddrinfo(HOST, PORT, AF_UNSPEC,
                           SOCK_STREAM, 0, AI_PASSIVE):
        af, socktype, proto, canonname, sockaddr = res

        try:
            webClient = socket(af, socktype)
        except OSError as msg:
            webClient = None
            continue
        try:
            webClient.connect(sockaddr)
        except OSError as msg:
            webClient.close()
            webClient = None
            continue
        break

    if webClient is None:
        print('could not open socket')
        sys.exit(1)

    buf = []  # save the received content
    with webClient:
        webClient.send(header_send)
        print('hugh')
        while True:
            recv = webClient.recv(BUFSIZ)  # bytes
    #		print(recv)
            if recv:
                buf.append(recv.decode())
            else:
                break
        data = ''.join(buf).encode()  # list to str
        data = data.decode()

        print(data)
        # note "encoding = 'utf-8'", or it will raise UnicodeEncodeError
        with open('out.txt', 'w', encoding='utf-8') as f:
            f.write(data)


def main():

    header_send = b'GET / HTTP/1.1\r\nHost: www.baidu.com\r\nConnection: close\r\n\r\n'

    HOST = 'www.baidu.com'
    PORT = 80
    BUFSIZ = 1024

    send(HOST, PORT, BUFSIZ, header_send)


if __name__ == '__main__':
    main()
