#!/usr/bin/python
# -*- coding: UTF-8 -*-

import requests
import re

url = 'http://www.baidu.com/'

response = requests.get(url)

response.encoding = 'utf-8'

html = response.text

print(html)