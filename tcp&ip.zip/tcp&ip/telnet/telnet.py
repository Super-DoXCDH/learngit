import getpass
import time
import telnetlib

HOST = "192.168.56.104"
user = input("Enter your remote account: ")
password = getpass.getpass()

tn = telnetlib.Telnet(HOST)

tn.read_until(b"login: ")
tn.write(user.encode('ascii') + b"\n")
if password:
    tn.read_until(b"Password: ")
    tn.write(password.encode('ascii') + b"\n")
time.sleep(2)
tn.write(b"ls\n")
tn.write(b"exit\n")

print(tn.read_all().decode('ascii'))