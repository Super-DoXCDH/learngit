from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
 
#创建FTP用户验证
authorizer = DummyAuthorizer()
#添加一个用户，依次为用户名，登录口令，目录，权限
authorizer.add_user('admin', '12345678', 'D:\\chromeDownloads\\temp\\tcp&ip\\ftp\\online\\server', perm='elradfmw')
#创建句柄
handler = FTPHandler
handler.authorizer = authorizer
#FTP被动模式下的端口号范围，主动模式不用设置
handler.passive_ports = range(2000, 2333)
#绑定监听的ip和端口号
server = FTPServer(('localhost', 21), handler)
#开启服务
server.serve_forever()