import ftplib
import sys
 
#获取服务器的ip地址（如192.168.1.107），使用sys.argv可以从命令行参数里面获取
if len(sys.argv) < 2:
    tmp ='localhost'
    sys.argv.append(tmp)
server_address = sys.argv[1]
#创建FTP实例，并显示欢迎界面
ftp = ftplib.FTP(server_address)
print(ftp.getwelcome())
#登录，输入服务器里添加过的用户名和口令
ftp.login('admin', '12345678')
 
#文件上传
def upload(fname):
    fd = open(fname, 'rb')
    new_name = input("input new name:")
    #以二进制的形式上传
    ftp.storbinary("STOR %s" % new_name, fd)
    fd.close()
    print("upload finished")
	
#文件下载
def download(fname):
    #构建文件的存储路径，这里用的是D盘,可以自行设置
    new_path = "D:\\chromeDownloads\\temp\\tcp&ip\\ftp\\online\\client\\" + fname
    fd = open(new_path, 'wb')
    #以二进制形式下载，注意第二个参数是fd.write，上传时是fd
    ftp.retrbinary("RETR %s" % fname, fd.write)
    fd.close()
    print("download finished")
 
def main():
    #选择操作，上传、下载、退出
    op = input("what do you want?(u/d/q)")
    if op == "u":
        #输入文件完整路径，必要时可以用绝对路径
        fname = input("input the file of path:")
        upload(fname)
    elif op == "d":
        fname = input("input the file name:")
        download(fname)
    else:
        print("quit now!")
    ftp.quit()
 
if __name__ == '__main__':
    main()